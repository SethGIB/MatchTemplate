This font is not an official font, but is inspired by the characters seen on "Lilo & Stitch"�� movie and "Stitch's Great Escape"�� attraction at Walt Disney World�� and is not affiliated with The Walt Disney Company�� in any way.

All official material on "Lilo & Stitch"�� & "Stitch's Great Escape"�� is copyright by Walt Disney Company. 

This is fan-produced material intended to promote interest in  "Lilo and Stitch" and "Stitch's Great Escape". 

The materials are provided as FREEWARE for your enjoyment, and is NOT be used for any commercial or publication purposes.
Introduction
~~~~~~~~~~~~
Thank you for downloading "Buka Bird"� Fonts TTF for Windows, I hope you enjoy using it. 

Requirements
~~~~~~~~~~~~
Windows 98,2000,Me�,XP�

Install
~~~~~~~
1. UnZip, install into C:\windows\fonts.

Uninstall
~~~~~~~~~
Delete the Startup\Settings\Control Panel\Fonts\(highlight font to be deleted)File\Delete.

Created By
~~~~~~~~~~
Date:06/30/2009
Filename: Buka Bird.zip 
Title: "Buka Bird"
Category: Movie, TV.
Archive: Fonts



Suggestions or comments sent to Steve Ferrera : supercarguy@hotmail.com
ENJOY!!!


RuFus


